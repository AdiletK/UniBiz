package com.example.unibiz;

import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout OrderLayout,ClientLayout;
    private Animation mShowButton ;
    private Animation mHideButton ;
    private Animation mHideLayout ;
    private Animation mShowLayout ;
    private FloatingActionButton floatBtn;
    private RelativeLayout mMainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        OrderLayout = findViewById(R.id.order_layout);
        ClientLayout = findViewById(R.id.client_layout);
        mMainLayout = findViewById(R.id.main_layout);

        initFloatButton();
    }

    private void initFloatButton() {
        floatBtn = findViewById(R.id.floatingActionButton);
        FloatingActionButton mOrderBtn = findViewById(R.id.floatingActionButton_order);
        FloatingActionButton mClientBtn = findViewById(R.id.floatingActionButton_client);

        mShowButton = AnimationUtils.loadAnimation(MainActivity.this,R.anim.show_button);
        mHideButton = AnimationUtils.loadAnimation(MainActivity.this,R.anim.hide_button);
        mHideLayout = AnimationUtils.loadAnimation(MainActivity.this,R.anim.hide_layout);
        mShowLayout = AnimationUtils.loadAnimation(MainActivity.this,R.anim.show_layout);

        floatBtn.setOnClickListener(this);
        mOrderBtn.setOnClickListener(this);
        mClientBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.floatingActionButton:
                if (OrderLayout.getVisibility()==View.VISIBLE && ClientLayout.getVisibility()==View.VISIBLE){
                    OrderLayout.setVisibility(View.GONE);
                    ClientLayout.setVisibility(View.GONE);
                    ClientLayout.startAnimation(mHideLayout);
                    OrderLayout.startAnimation(mHideLayout);
                    floatBtn.startAnimation(mHideButton);
                    floatBtn.setImageResource(R.mipmap.floating_button);

                }else {
                    OrderLayout.setVisibility(View.VISIBLE);
                    ClientLayout.setVisibility(View.VISIBLE);
                    ClientLayout.startAnimation(mShowLayout);
                    OrderLayout.startAnimation( mShowLayout);
                    floatBtn.startAnimation(mShowButton);
                    floatBtn.setImageResource(R.mipmap.changed_bg_float);

                }
        }
    }
}
