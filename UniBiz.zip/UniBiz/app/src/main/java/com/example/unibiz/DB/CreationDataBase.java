package com.example.unibiz.DB;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;



import static com.example.unibiz.DB.DBSchema.*;


public class CreationDataBase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "UniBiz.db";

    CreationDataBase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Client table
        db.execSQL("create table " + ClientTable.NAME + "(" +
                ClientTable.Cols._ID + " integer primary key autoincrement, " +

                ClientTable.Cols.C_UUID + ", " +
                ClientTable.Cols.NAME + ", " +
                ClientTable.Cols.PRICE + ", " +
                ClientTable.Cols.ID_CAT + " REFERENCES "+  CategoryTable.NAME + " ( " + CategoryTable.Cols.C_UUID + " ) "+ ", " +
                ClientTable.Cols.ID_EMPL + " references "+ EmployeTable.NAME + " ( " + EmployeTable.Cols.E_UUID + " ) " + ", " +
                ClientTable.Cols.ID_ITEMS + " references "+ ItemsTable.NAME + " ( " + ItemsTable.Cols.ID_UUID + " ) " + ", " +
                ClientTable.Cols.MODEL + ", " +
                ClientTable.Cols.NOMER + ", " +
                ClientTable.Cols.IMEI + ", " +
                ClientTable.Cols.VISIT_DATE + ", " +
                ClientTable.Cols.DATE_BORN +
                " ) "
        );

        //Product table
        db.execSQL(
                "create table " + ProductTable.NAME + "(" +
                        ProductTable.Cols._ID + " integer primary key autoincrement, " +

                        ProductTable.Cols.P_UUID + ", " +
                        ProductTable.Cols.NAME + ", " +
                        ProductTable.Cols.IMEI_CODE + "," +
                        ProductTable.Cols.COUNT + "," +
                        ProductTable.Cols.PRICE + "," +
                        ProductTable.Cols.ID_EMPL + " REFERENCES "+EmployeTable.NAME + " ( " + EmployeTable.Cols.E_UUID + " ) " + ", " +
                        ProductTable.Cols.ID_SUPL + " references "+   SupplierTable.NAME + " ( " + SupplierTable.Cols.S_UUID + " ) " + ", " +
                        ProductTable.Cols.ID_ITEMS + " references "+ ItemsTable.NAME + " ( " + ItemsTable.Cols.ID_UUID + " ) " + ", " +
                        ProductTable.Cols.DATE +
                        ")"
        );

        //   Category table
        db.execSQL(
                "create table " + CategoryTable.NAME + "("+
                        CategoryTable.Cols._ID + " integer primary key autoincrement, " +

                        CategoryTable.Cols.C_UUID + ", " +
                        CategoryTable.Cols.NAME + ", " +
                        CategoryTable.Cols.PRICE + ", " +
                        CategoryTable.Cols.DATE + ", " +
                        CategoryTable.Cols.IMAGE  +
                        ")"
        );

        //Items table
        db.execSQL(
                "create table "+ ItemsTable.NAME + "("+
                        ItemsTable.Cols._ID + " integer primary key autoincrement, "+

                        ItemsTable.Cols.ID_UUID +", " +
                        ItemsTable.Cols.ITEM +
                        ")"
        );

        // Employe table
        db.execSQL(
                "create table "+ EmployeTable.NAME + "("+
                       EmployeTable.Cols._ID +  " integer primary key autoincrement, "+

                       EmployeTable.Cols.E_UUID + ", " +
                       EmployeTable.Cols.NAME + ", " +
                       EmployeTable.Cols.ID_ITEMS + " references "+ ItemsTable.NAME + " ( " + ItemsTable.Cols.ID_UUID + " ) " + ", " +
                       EmployeTable.Cols.JOB + ", " +
                       EmployeTable.Cols.SEX + ", "+
                       EmployeTable.Cols.IMAGE + ", "+
                       EmployeTable.Cols.NOMER + ", "+
                       EmployeTable.Cols.EMAIL + ", "+
                       EmployeTable.Cols.DATE_BORN + ", "+
                       EmployeTable.Cols.DATE_COME + ", "+
                       EmployeTable.Cols.DATE_OUT + ", "+
                       EmployeTable.Cols.ADDRESS +
                        ")"
        );
        // Supplier table
        db.execSQL(
                "create table "+ SupplierTable.NAME + "("+
                        SupplierTable.Cols._ID +  " integer primary key autoincrement, "+

                        SupplierTable.Cols.S_UUID + ", " +
                        SupplierTable.Cols.NAME + ", " +
                        SupplierTable.Cols.ORGANIZATION + ", " +
                        SupplierTable.Cols.ID_ITEMS + " references "+ ItemsTable.NAME + " ( " + ItemsTable.Cols.ID_UUID + " ) " + ", " +
                        SupplierTable.Cols.PHONE + ", "+
                        SupplierTable.Cols.EMAIL + ", "+
                        SupplierTable.Cols.ADDRESS + ", "+
                        SupplierTable.Cols.VISIT_DATE + ", "+
                        SupplierTable.Cols.DATE_COME + ", "+
                        SupplierTable.Cols.DATE_OUT +
                        ")"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_NAME);
        onCreate(db);

    }


}
